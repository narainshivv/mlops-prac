pip install azureml-core
